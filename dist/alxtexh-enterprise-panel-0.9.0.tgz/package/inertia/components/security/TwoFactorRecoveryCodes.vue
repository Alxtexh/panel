<script setup lang="ts">
/**
 * The recovery codes, hidden until asked for.
 *
 * MOVED FROM THE REFERENCE APP. Its Wayfinder `regenerateRecoveryCodes` helper
 * and the composable's three fetch URLs became props.
 *
 * HIDDEN BY DEFAULT, and that is not decoration: these are eight passwords, and
 * a settings screen somebody opens beside a colleague should not put them on the
 * wall. Fetching them on mount but not showing them is the compromise - the
 * reveal is instant, and the codes were never rendered until asked for.
 */
import { Form } from '@inertiajs/vue3'
import { Eye, EyeOff, LockKeyhole, RefreshCw } from '@lucide/vue'
import {
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle,
    PkAlertError as AlertError,
    PkButton as Button,
} from '@alxtexh-enterprise/panel'
import { nextTick, onMounted, ref, useTemplateRef } from 'vue'
import type { TwoFactorRoutes } from '../../composables/useTwoFactorAuth'
import { useTwoFactorAuth } from '../../composables/useTwoFactorAuth'

const props = defineProps<{
    routes: TwoFactorRoutes
    /** Where "regenerate" posts. */
    regenerateUrl: string
}>()

const { recoveryCodesList, fetchRecoveryCodes, errors } = useTwoFactorAuth(props.routes)
const isRecoveryCodesVisible = ref<boolean>(false)
const recoveryCodeSectionRef = useTemplateRef('recoveryCodeSectionRef')

const toggleRecoveryCodesVisibility = async () => {
    if (!isRecoveryCodesVisible.value && !recoveryCodesList.value.length) {
        await fetchRecoveryCodes()
    }

    isRecoveryCodesVisible.value = !isRecoveryCodesVisible.value

    if (isRecoveryCodesVisible.value) {
        await nextTick()
        recoveryCodeSectionRef.value?.scrollIntoView({ behavior: 'smooth' })
    }
}

onMounted(async () => {
    if (!recoveryCodesList.value.length) {
        await fetchRecoveryCodes()
    }
})
</script>

<template>
    <Card class="w-full">
        <CardHeader>
            <CardTitle class="flex gap-3">
                <LockKeyhole class="size-4" />2FA recovery codes
            </CardTitle>
            <CardDescription>
                Recovery codes let you regain access if you lose your 2FA device. Store them in a
                secure password manager.
            </CardDescription>
        </CardHeader>
        <CardContent>
            <div
                class="flex flex-col gap-3 select-none sm:flex-row sm:items-center sm:justify-between"
            >
                <Button class="w-fit" @click="toggleRecoveryCodesVisibility">
                    <component :is="isRecoveryCodesVisible ? EyeOff : Eye" class="size-4" />
                    {{ isRecoveryCodesVisible ? 'Hide' : 'View' }} recovery codes
                </Button>

                <Form
                    v-if="isRecoveryCodesVisible && recoveryCodesList.length"
                    :action="props.regenerateUrl"
                    method="post"
                    :options="{ preserveScroll: true }"
                    #default="{ processing }"
                    @success="fetchRecoveryCodes"
                >
                    <Button variant="secondary" type="submit" :disabled="processing">
                        <RefreshCw /> Regenerate codes
                    </Button>
                </Form>
            </div>
            <div
                :class="[
                    'relative overflow-hidden transition-all duration-300',
                    isRecoveryCodesVisible ? 'h-auto opacity-100' : 'h-0 opacity-0',
                ]"
            >
                <div v-if="errors?.length" class="mt-6">
                    <AlertError :errors="errors" />
                </div>
                <div v-else class="mt-3 space-y-3">
                    <div
                        ref="recoveryCodeSectionRef"
                        class="bg-muted grid gap-1 rounded-lg p-4 font-mono text-sm"
                    >
                        <div v-if="!recoveryCodesList.length" class="space-y-2">
                            <div
                                v-for="n in 8"
                                :key="n"
                                class="bg-muted-foreground/20 h-4 animate-pulse rounded"
                            />
                        </div>
                        <div v-for="(code, index) in recoveryCodesList" v-else :key="index">
                            {{ code }}
                        </div>
                    </div>
                    <p class="text-muted-foreground text-xs select-none">
                        Each recovery code can be used once to access your account and will be
                        removed after use. If you need more, click
                        <span class="font-bold">Regenerate codes</span> above.
                    </p>
                </div>
            </div>
        </CardContent>
    </Card>
</template>
