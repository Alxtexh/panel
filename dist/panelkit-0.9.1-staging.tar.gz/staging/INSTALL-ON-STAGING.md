# Installing PanelKit 0.9.1 on staging, by hand

For `/var/www/html/Paygridbilling-new`. Everything here is offline — no
registry, no token, no GitHub. That is the point of this bundle: it works
before the GitHub Packages side is set up, and it stays working if that side
breaks.

**Read `PANELKIT.md` for how to BUILD with PanelKit.** This file is only how to
get it onto the box.

---

## What is in this folder

| File | What it is |
|---|---|
| `alxtexh-enterprise-panel-0.9.1.tgz` | The **client half** — 85 `.vue` screens plus the compiled `dist`. Nothing renders without this. |
| `panelkit-panel-0.9.1-composer.tar.gz` | The **PHP half** — the Composer package, source only. |
| `CHECKSUMS.txt` | sha256 of the npm tarball. Check it. |
| `.npmrc.example` | For later, when you switch to pulling from GitHub Packages. Not needed today. |
| `PANELKIT.md` | The build guide. The one document to keep. |
| `UPGRADING.md`, `CHANGELOG.md` | What changed and what breaks. |

---

## 0. Before anything

```bash
cd /var/www/html/Paygridbilling-new
```

**Take a database dump and a copy of `.env` first.** Step 5 runs migrations,
which is the only step here that cannot be undone by deleting a directory.

```bash
cp .env .env.before-panelkit
```

Check the tarball is the one that left the build machine:

```bash
sha256sum -c CHECKSUMS.txt
```

Expected: `07e473f79911e8f926b59461ef7678485eb3cab777593224f8818c368117f1ac`

---

## 1. Put the two halves where the app can see them

```bash
mkdir -p vendor-src vendor-js
tar xzf panelkit-panel-0.9.1-composer.tar.gz -C vendor-src
cp alxtexh-enterprise-panel-0.9.1.tgz vendor-js/
```

You now have `vendor-src/panelkit-panel/` (PHP) and the tarball in
`vendor-js/`.

---

## 2. The PHP half, as a path repository

In `composer.json`:

```json
{
    "repositories": [
        { "type": "path", "url": "vendor-src/panelkit-panel", "options": { "symlink": false } }
    ]
}
```

Then:

```bash
composer require panelkit/panel:@dev
```

**`"symlink": false` matters.** With a symlink, Composer links the directory and
an `artisan` command that writes into the package writes into your source tree.
Copying keeps `vendor/` disposable, which is what `vendor/` is for.

Confirm Laravel found it:

```bash
php artisan | grep panel:
```

You should see `panel:install`, `panel:doctor`, `panel:update` and the
generators. If that list is empty, package discovery did not run —
`php artisan package:discover` and look at the error it prints.

---

## 3. The client half

```bash
npm install ./vendor-js/alxtexh-enterprise-panel-0.9.1.tgz @vitejs/plugin-vue
```

This is the step that strands people. **The Composer package contains zero
`.vue` files** — deliberately, because Composer is not a JavaScript registry.
If you skip this, every route answers 200 and every screen is blank.

Check it actually landed:

```bash
ls node_modules/@alxtexh-enterprise/panel/inertia/pages/ | head
```

Screens should be listed. An empty directory means the install silently
resolved something else.

---

## 4. Install into the application

```bash
php artisan panel:install
```

It writes a panel class, the Inertia bootstrap, the page files each packaged
screen needs, and merges its `@source` lines into `resources/css/app.css`.

**It does not overwrite what you have written.** Config is published once and
is yours from then on; the installer reports new keys rather than replacing the
file.

---

## 5. Migrations — the one irreversible step

```bash
php artisan migrate --pretend    # read this first
php artisan migrate
```

`--pretend` prints the SQL without running it. On a billing schema, read it
before you run it. `panel:update` deliberately never migrates for you; that is
a maintenance-window decision, not a side effect of an update.

---

## 6. Build and check

```bash
npm run build
php artisan panel:doctor
```

`panel:doctor` exits non-zero when something is wrong and names it. Take it
seriously — it is the check that catches the stylesheet problem below.

Then sign in:

```bash
php artisan panel:make-user
```

---

## If the panel renders with no styling

This is the most common failure and it produces **no error at all** — the build
succeeds, the markup is correct, and the page has no layout, no colour and no
spacing.

Tailwind does not scan `node_modules`. These two lines must be in
`resources/css/app.css`:

```css
@source '../../node_modules/@alxtexh-enterprise/panel/dist/**/*.js';
@source '../../node_modules/@alxtexh-enterprise/panel/inertia/**/*.{vue,ts}';
```

**Both.** One package, two paths, because its halves ship differently: `dist`
is compiled so its class names are string literals in built render functions,
while `inertia` ships raw source so you can override a screen. Scan one and the
other's utilities are purged.

`php artisan panel:update` writes them for you, including from the older
`@panelkit/ui` and `@panelkit/panel` names.

---

## Upgrading later, still offline

Copy the new tarballs across, then:

```bash
rm -rf vendor-src/panelkit-panel && tar xzf panelkit-panel-<v>-composer.tar.gz -C vendor-src
composer update panelkit/panel
npm install ./vendor-js/alxtexh-enterprise-panel-<v>.tgz
php artisan panel:update
php artisan wayfinder:generate --with-form
npm run build
```

`panel:update` writes page files for screens the new version routes and your
app has no file for — the white-page failure it exists to prevent — refreshes
`AGENTS.md`, repoints the stylesheet, and **reports** pending migrations
without running them. Migrate when you have decided to.

---

## Switching to GitHub Packages later

When you want `npm install` to resolve automatically instead of from a file,
put `.npmrc.example` next to `package.json` as `.npmrc`:

```
@alxtexh-enterprise:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${GITHUB_TOKEN}
```

Export a `read:packages` token as `GITHUB_TOKEN` and:

```bash
npm install @alxtexh-enterprise/panel
```

The token is read from the environment, so `.npmrc` holds no secret and can be
committed. **A 404 means you reached npmjs.com** — that scope is not ours
there. Check the `.npmrc` is in scope and the variable is exported.

Nothing above stops working when you switch. The file install and the registry
install produce the same `node_modules` contents.

---

## Version

PanelKit **0.9.1**. Composer `panelkit/panel`, npm
`@alxtexh-enterprise/panel` — versioned together, so keep both on `0.9.x`.
Pin `"panelkit/panel": "^0.9.1"`: on a `0.x` package the minor is the breaking
position.

Verified before this bundle was cut: 1,744 PHP tests, 148 JS tests, both
builds, both type checkers, Pint, ESLint, Prettier, and a scripted install into
a clean Laravel application.
