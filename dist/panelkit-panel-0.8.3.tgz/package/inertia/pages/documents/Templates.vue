<script setup lang="ts">
/**
 * The documents this panel can design.
 *
 * IT SAYS WHICH ONES HAVE BEEN DESIGNED. A row of identical cards tells somebody
 * nothing about where they left off, and "still on the shipped defaults" is the
 * single most useful fact about a template - it is the difference between a
 * document that was thought about and one that has your company name set to
 * "Your company".
 *
 * THE LIST COMES FROM THE REGISTRY, so a kind a plugin registered appears here
 * with no edit to this file.
 */
import { Head, Link } from '@inertiajs/vue3'
import { computed } from 'vue'

const props = defineProps<{
    prefix: string
    kinds: { id: string; label: string; description: string; version: number | null }[]
}>()

const base = computed(() => (props.prefix === '/' ? '' : props.prefix))
</script>

<template>
    <Head title="Document templates" />

    <div class="flex flex-col gap-4 p-4">
        <header>
            <h1 class="text-xl font-semibold tracking-tight">Document templates</h1>
            <p class="text-muted-foreground text-sm">
                How the documents that leave this system look when they are printed.
            </p>
        </header>

        <div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <Link
                v-for="kind in kinds"
                :key="kind.id"
                :href="`${base}/documents/${kind.id}`"
                class="bg-card hover:border-muted-foreground/40 flex flex-col gap-1 rounded-lg border p-4 transition-colors"
            >
                <span class="font-medium">{{ kind.label }}</span>
                <span class="text-muted-foreground text-sm">{{ kind.description }}</span>
                <span class="text-muted-foreground mt-2 text-xs">
                    {{
                        kind.version === null
                            ? 'Still on the shipped defaults'
                            : `Version ${kind.version}`
                    }}
                </span>
            </Link>
        </div>

        <!-- An empty registry is a real state - an installation whose provider
             registered no kinds - and saying so beats an empty page. -->
        <p v-if="kinds.length === 0" class="text-muted-foreground text-sm">
            No document kinds are registered.
        </p>
    </div>
</template>
